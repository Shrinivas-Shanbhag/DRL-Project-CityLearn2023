import os
import numpy as np
from stable_baselines3 import SAC
from envfactory.citylearn_env import create_citylearn_env
from rewards.user_reward import SubmissionReward
from stable_baselines3.common.vec_env.base_vec_env import VecEnvWrapper
from stable_baselines3.common.vec_env import DummyVecEnv
from gym.spaces import Box
import gym

class CustomNormalizedObservationWrapper(VecEnvWrapper):
    def __init__(self, venv, scale=True):
        super(CustomNormalizedObservationWrapper, self).__init__(venv)
        self.scale = scale

    def reset(self, **kwargs):
        observations = self.venv.reset(**kwargs)
        if self.scale:
            self.obs_rms.update(observations)
            observations = self._normalize_obs(observations)
        return observations, None  # Ensure both observations and reset information are returned

    def step_wait(self):
        observations, rewards, dones, infos = self.venv.step_wait()
        if self.scale:
            observations = self._normalize_obs(observations)
        return observations, rewards, dones, infos

def convert_to_gym_space(space):
    if isinstance(space, Box):
        return Box(low=space.low, high=space.high, dtype=space.dtype)
    elif isinstance(space, list):
        # Assuming each element in the list is a scalar
        low = np.min(space)
        high = np.max(space)
        return Box(low=low, high=high, shape=(len(space),), dtype=np.float32)
    else:
        raise NotImplementedError(f"Space type {type(space)} not supported. Please extend the conversion logic.")

class SACAgent:
    def __init__(self, env):
        gym_space = convert_to_gym_space(env.observation_space)
        self.env = DummyVecEnv([lambda: env])
        self.env = CustomNormalizedObservationWrapper(self.env)
        self.model = SAC("MlpPolicy", self.env, verbose=1)

    def train(self, total_timesteps):
        self.model.learn(total_timesteps=total_timesteps)

    def register_reset(self, observations):
        self.env.reset()
        return self.predict(observations)

    def predict(self, observations):
        action, _ = self.model.predict(observations, deterministic=True)
        return action

def train_sac_agent(env, total_timesteps=10000):
    sac_agent = SACAgent(env)
    sac_agent.train(total_timesteps)
    return sac_agent

if __name__ == '__main__':
    # Load your CityLearn environment configuration
    class Config:
        data_dir = './../data/'
        SCHEMA = os.path.join(data_dir, 'schemas/warm_up/schema.json')
        num_episodes = 1

    config = Config()

    # Create the CityLearn environment and wrapper
    env, wrapper_env = create_citylearn_env(config, SubmissionReward)

    # Train SAC agent
    sac_agent = train_sac_agent(env)

    # Evaluate the SAC agent
    observations = env.reset()
    actions = sac_agent.register_reset(observations)

    print("train successful")

    while True:
        observations, _, done, _ = env.step(actions)
        if not done:
            actions = sac_agent.predict(observations)
        else:
            break
