# Add your reward functions here

Your reward functio  needs to be a subclass of the Citylearn environment's RewardFunction class. Specifically, it should implement the `calculate` function that takes in a list of observations and returns the reward.

Refer to the comfort reward (`comfort_reward.py`) example and create your agents in the same format