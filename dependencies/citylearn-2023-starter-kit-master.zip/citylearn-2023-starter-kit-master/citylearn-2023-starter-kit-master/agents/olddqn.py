import os
from stable_baselines3 import DQN
from envfactory.citylearn_env import create_citylearn_env
from rewards.user_reward import SubmissionReward

class DQNAgent:
    def __init__(self, env):
        self.env = env
        self.model = DQN("MlpPolicy", env, verbose=1)

    def train(self, total_timesteps):
        self.model.learn(total_timesteps=total_timesteps)

    def register_reset(self, observations):
        self.env.reset()
        return self.predict(observations)

    def predict(self, observations):
        action, _ = self.model.predict(observations, deterministic=True)
        return action

def train_dqn_agent(env, total_timesteps=10000):
    dqn_agent = DQNAgent(env)
    dqn_agent.train(total_timesteps)
    return dqn_agent

if __name__ == '__main__':
    # Load your CityLearn environment configuration
    class Config:
        data_dir = './../data/'
        SCHEMA = os.path.join(data_dir, 'schemas/warm_up/schema.json')
        num_episodes = 1

    config = Config()

    # Create the CityLearn environment and wrapper
    env, wrapper_env = create_citylearn_env(config, SubmissionReward)

    # Train DQN agent
    dqn_agent = train_dqn_agent(env)

    # Evaluate the DQN agent
    observations = env.reset()
    actions = dqn_agent.register_reset(observations)

    print("train successful")

    while True:
        observations, _, done, _ = env.step(actions)
        if not done:
            actions = dqn_agent.predict(observations)
        else:
            break

    # # Optionally, evaluate the rule-based controller
    # rbc_agent = BasicRBCAgent(wrapper_env)
    # observations = env.reset()
    # actions = rbc_agent.register_reset(observations)
    #
    # while True:
    #     observations, _, done, _ = env.step(actions)
    #     if not done:
    #         actions = rbc_agent.predict(observations)
    #     else:
    #         break



----

import os
import gym
import numpy as np
from stable_baselines3 import DQN
from envfactory.citylearn_env import create_citylearn_env
from rewards.user_reward import SubmissionReward
from citylearn.wrappers import NormalizedObservationWrapper, StableBaselines3Wrapper

class Discretizer:
    def __init__(self, observation_space, num_bins):
        self.observation_space = observation_space
        self.num_bins = num_bins
        self.bin_edges = self.create_bins()

    def create_bins(self):
        bins = []
        for space in self.observation_space:
            if isinstance(space, np.ndarray) or hasattr(space, 'low') and hasattr(space, 'high'):  # Handle Box spaces
                edges = np.linspace(space.low, space.high, self.num_bins + 1)
            else:
                low, high = space
                edges = np.linspace(low, high, self.num_bins + 1)
            bins.append(edges)
        return bins

    def discretize(self, observation):
        discrete_observation = []
        for i, space in enumerate(self.observation_space):
            if isinstance(space, np.ndarray) or hasattr(space, 'low') and hasattr(space, 'high'):  # Handle Box spaces
                discrete_observation.extend(np.digitize(observation[i], self.bin_edges[i]) - 1)
            else:
                discrete_observation.append(np.digitize(observation[i], self.bin_edges[i]) - 1)
        return np.array(discrete_observation, dtype=np.int)

class DQNAgent:
    def __init__(self, env, discretizer):
        self.env = env
        self.discretizer = discretizer
        self.model = DQN("MlpPolicy", env, verbose=1)

    def train(self, total_timesteps):
        self.model.learn(total_timesteps=total_timesteps)

    def register_reset(self, observations):
        self.env.reset()
        return self.predict(observations)

    def predict(self, observations):
        discrete_observations = self.discretizer.discretize(observations)
        action, _ = self.model.predict(discrete_observations, deterministic=True)
        return action

def train_dqn_agent(env, total_timesteps=10000, num_bins=10):
    observation_space = env.observation_space
    discretizer = Discretizer(observation_space, num_bins)
    dqn_agent = DQNAgent(env, discretizer)
    dqn_agent.train(total_timesteps)
    return dqn_agent

if __name__ == '__main__':
    # Load your CityLearn environment configuration
    class Config:
        data_dir = './../data/'
        SCHEMA = os.path.join(data_dir, 'schemas/warm_up/schema.json')
        num_episodes = 1

    config = Config()

    # Create the CityLearn environment and wrapper
    env, wrapper_env = create_citylearn_env(config, SubmissionReward)

    # Train DQN agent
    dqn_agent = train_dqn_agent(env)

    # Evaluate the DQN agent
    observations = env.reset()
    actions = dqn_agent.register_reset(observations)

    print("train successful")

    while True:
        observations, _, done, _ = env.step(actions)
        if not done:
            actions = dqn_agent.predict(observations)
        else:
            break
