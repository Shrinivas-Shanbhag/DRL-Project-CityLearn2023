import os
import numpy as np
from gymnasium.spaces import Discrete
from stable_baselines3 import PPO
from envfactory.citylearn_env import create_citylearn_env
from rewards.user_reward import SubmissionReward
from citylearn.wrappers import NormalizedObservationWrapper, StableBaselines3Wrapper

class PPOAgent:
    def __init__(self, env):
        self.env = NormalizedObservationWrapper(env)
        self.env = StableBaselines3Wrapper(self.env)
        self.model = PPO("MlpPolicy", self.env, verbose=1)

    def train(self, total_timesteps):
        self.model.learn(total_timesteps=total_timesteps)

    def register_reset(self, observations):
        self.env.reset()
        return self.predict(observations)

    def predict(self, observations):
        action, _ = self.model.predict(observations, deterministic=True)
        return action

def train_ppo_agent(env, total_timesteps=10000):
    ppo_agent = PPOAgent(env)
    ppo_agent.train(total_timesteps)
    return ppo_agent

if __name__ == '__main__':
    # Load your CityLearn environment configuration
    class Config:
        data_dir = './../data/'
        SCHEMA = os.path.join(data_dir, 'schemas/warm_up/schema.json')
        num_episodes = 1

    config = Config()

    # Create the CityLearn environment and wrapper
    env, wrapper_env = create_citylearn_env(config, SubmissionReward)

    # Train DQN agent
    ppo_agent = train_ppo_agent(env)

    # Evaluate the DQN agent
    observations = env.reset()
    actions = ppo_agent.register_reset(observations)

    print("train successful")

    while True:
        observations, _, done, _ = env.step(actions)
        if not done:
            actions = ppo_agent.predict(observations)
        else:
            break
