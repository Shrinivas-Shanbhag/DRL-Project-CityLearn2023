import os
import numpy as np
from gymnasium.spaces import Discrete
from stable_baselines3 import DQN
from envfactory.citylearn_env import create_citylearn_env
from rewards.user_reward import SubmissionReward
from citylearn.wrappers import NormalizedObservationWrapper, StableBaselines3Wrapper

class Discretizer:
    def __init__(self, num_bins, action_space):
        self.num_bins = num_bins
        self.action_space = action_space
        self.bin_edges = self.create_bins()

    def create_bins(self):
        if isinstance(self.action_space, Discrete):
            # For Discrete action space, use the predefined number of bins
            return np.linspace(0, self.num_bins, self.num_bins + 1)

        # For continuous action space, use the low and high values
        return [np.linspace(dim.low, dim.high, self.num_bins + 1) for dim in self.action_space]

    def discretize(self, values):
        if isinstance(self.action_space, Discrete):
            # For Discrete action space, map values to discrete actions
            return np.digitize(values, self.bin_edges[:-1], right=False)

        # For continuous action space, discretize each dimension separately
        return [np.digitize(v, edges, right=False) for v, edges in zip(values, self.bin_edges)]

class DQNAgent:
    def __init__(self, env, discretizer):
        self.env = NormalizedObservationWrapper(env)
        self.env = StableBaselines3Wrapper(self.env)
        self.discretizer = discretizer
        self.model = DQN("MlpPolicy", self.env, verbose=1)

    def train(self, total_timesteps):
        self.model.learn(total_timesteps=total_timesteps)

    def register_reset(self, observations):
        self.env.reset()
        return self.predict(observations)

    def predict(self, observations):
        # Discretize the continuous action before prediction
        discrete_actions = [self.discretizer.discretize(a) for a in observations]
        action, _ = self.model.predict(discrete_actions, deterministic=True)
        return action

def train_dqn_agent(env, total_timesteps=10000, num_bins=10):
    # Create a discretizer for the action space
    action_discretizer = Discretizer(num_bins, env.action_space)

    dqn_agent = DQNAgent(env, action_discretizer)
    dqn_agent.train(total_timesteps)
    return dqn_agent

if __name__ == '__main__':
    # Load your CityLearn environment configuration
    class Config:
        data_dir = './../data/'
        SCHEMA = os.path.join(data_dir, 'schemas/warm_up/schema.json')
        num_episodes = 1

    config = Config()

    # Create the CityLearn environment and wrapper
    env, wrapper_env = create_citylearn_env(config, SubmissionReward)

    # Train DQN agent
    dqn_agent = train_dqn_agent(env)

    # Evaluate the DQN agent
    observations = env.reset()
    actions = dqn_agent.register_reset(observations)

    print("train successful")

    while True:
        observations, _, done, _ = env.step(actions)
        if not done:
            actions = dqn_agent.predict(observations)
        else:
            break
