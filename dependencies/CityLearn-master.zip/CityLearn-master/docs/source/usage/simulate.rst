=========================
How to Setup a Simulation
=========================

A detailed line-by-line description of how to set up a simulation is coming soon |:smiley:|! In the meantime please, refer to `QuickStart`_ for examples on how to setup simulations for different control architectures.

.. _QuickStart: ../quickstart.ipynb