=======
Actions
=======

The action is a real number between [-1.0, 1.0] that prescribes the proportion of a storage device capacity that is to be charged or discharged.

.. csv-table::
   :file: ../../../assets/tables/citylearn_actions.csv
   :header-rows: 1