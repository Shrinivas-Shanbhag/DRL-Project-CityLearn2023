.. _monitor:

Monitor Wrapper
===============

.. automodule:: stable_baselines3.common.monitor
  :members:
